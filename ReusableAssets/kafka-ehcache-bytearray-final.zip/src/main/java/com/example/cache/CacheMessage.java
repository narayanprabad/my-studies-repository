
package com.example.cache;

import java.io.Serializable;

public class CacheMessage implements Serializable {
    private String cacheName;
    private String key;
    private Object value;

    public CacheMessage() {}

    public CacheMessage(String cacheName, String key, Object value) {
        this.cacheName = cacheName;
        this.key = key;
        this.value = value;
    }

    public String getCacheName() { return cacheName; }
    public String getKey() { return key; }
    public Object getValue() { return value; }
}
