
package com.example.cache;

import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cache")
public class CacheController {

    private final CacheManager cacheManager;
    private final KafkaProducerService producerService;

    public CacheController(CacheManager cacheManager, KafkaProducerService producerService) {
        this.cacheManager = cacheManager;
        this.producerService = producerService;
    }

    @PostMapping("/put")
    public String put(@RequestParam String cacheName, @RequestParam String key, @RequestBody Object value) {
        cacheManager.getCache(cacheName).put(key, value);
        producerService.sendCacheUpdate(cacheName, key, value);
        return "Put Success";
    }

    @GetMapping("/get")
    public Object get(@RequestParam String cacheName, @RequestParam String key) {
        var element = cacheManager.getCache(cacheName).get(key);
        return element != null ? element.get() : null;
    }

    @DeleteMapping("/delete")
    public String delete(@RequestParam String cacheName, @RequestParam String key) {
        cacheManager.getCache(cacheName).evict(key);
        producerService.sendCacheUpdate(cacheName, key, null);
        return "Delete Success";
    }
}
