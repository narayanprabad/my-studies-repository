
package com.example.cache;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.time.Duration;
import java.util.*;

@Component
public class KafkaConsumerService {

    private KafkaConsumer<String, byte[]> consumer;
    private final CacheManager cacheManager;

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    public KafkaConsumerService(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @PostConstruct
    public void init() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer.class.getName());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "cache-sync-group");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        consumer = new KafkaConsumer<>(props);
        consumer.assign(List.of(new TopicPartition("cache-updates", 0)));
    }

    @Scheduled(fixedDelay = 500)
    public void pollKafka() {
        ConsumerRecords<String, byte[]> records = consumer.poll(Duration.ofMillis(300));
        for (ConsumerRecord<String, byte[]> record : records) {
            try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(record.value()))) {
                CacheMessage message = (CacheMessage) in.readObject();
                var cache = cacheManager.getCache(message.getCacheName());
                if (cache != null) {
                    if (message.getValue() != null) {
                        cache.put(message.getKey(), message.getValue());
                    } else {
                        cache.evict(message.getKey());
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @PreDestroy
    public void shutdown() {
        if (consumer != null) {
            consumer.close();
        }
    }
}
