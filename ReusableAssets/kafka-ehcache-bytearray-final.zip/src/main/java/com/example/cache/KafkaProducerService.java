
package com.example.cache;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;

@Service
public class KafkaProducerService {
    private final KafkaTemplate<String, byte[]> kafkaTemplate;

    public KafkaProducerService(KafkaTemplate<String, byte[]> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendCacheUpdate(String cacheName, String key, Object value) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (ObjectOutputStream out = new ObjectOutputStream(bos)) {
                out.writeObject(new CacheMessage(cacheName, key, value));
            }
            kafkaTemplate.send("cache-updates", key, bos.toByteArray());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
