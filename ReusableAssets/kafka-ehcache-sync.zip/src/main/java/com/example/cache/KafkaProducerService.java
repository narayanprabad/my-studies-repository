
package com.example.cache;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.Map;

@Service
public class KafkaProducerService {
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper mapper = new ObjectMapper();

    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendCacheUpdate(String cacheName, String key, Object value) {
        try {
            Map<String, Object> map = new HashMap<>();
            map.put("cacheName", cacheName);
            map.put("key", key);
            map.put("value", value);
            kafkaTemplate.send("cache-updates", key, mapper.writeValueAsString(map));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
