
package com.example.cache;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.time.Duration;
import java.util.*;

@Component
public class KafkaConsumerService {

    private KafkaConsumer<String, String> consumer;
    private final CacheManager cacheManager;
    private final ObjectMapper mapper = new ObjectMapper();

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    public KafkaConsumerService(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @PostConstruct
    public void init() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "cache-sync-group");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        consumer = new KafkaConsumer<>(props);
        consumer.assign(List.of(new TopicPartition("cache-updates", 0)));
    }

    @Scheduled(fixedDelay = 500)
    public void pollKafka() {
        ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(300));
        for (ConsumerRecord<String, String> record : records) {
            try {
                Map<String, Object> message = mapper.readValue(record.value(), new TypeReference<>() {});
                String cacheName = (String) message.get("cacheName");
                String key = (String) message.get("key");
                Object value = message.get("value");

                var cache = cacheManager.getCache(cacheName);
                if (cache != null) {
                    if (value != null) {
                        cache.put(key, value);
                    } else {
                        cache.evict(key);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @PreDestroy
    public void shutdown() {
        if (consumer != null) {
            consumer.close();
        }
    }
}
