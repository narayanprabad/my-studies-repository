
package com.example.demo;

import java.io.Serializable;

public class CacheEvent implements Serializable {
    private String key;
    private TypedCacheEntry value;
    private String action;

    public CacheEvent() {}

    public CacheEvent(String key, TypedCacheEntry value, String action) {
        this.key = key;
        this.value = value;
        this.action = action;
    }

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }

    public TypedCacheEntry getValue() { return value; }
    public void setValue(TypedCacheEntry value) { this.value = value; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
}
