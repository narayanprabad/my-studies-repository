
package com.example.demo;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import org.springframework.web.bind.annotation.*;

@RestController
public class CacheController {

    private final Cache cache;
    private final CacheEventProducer producer;

    public CacheController(net.sf.ehcache.CacheManager cacheManager, CacheEventProducer producer) {
        this.cache = cacheManager.getCache("demoCache");
        this.producer = producer;
    }

    @PostMapping("/put")
    public String put(@RequestParam String key, @RequestBody Object value) throws Exception {
        TypedCacheEntry entry = new TypedCacheEntry(value);
        cache.put(new Element(key, entry));
        producer.send(new CacheEvent(key, entry, "PUT"));
        return "PUT success";
    }

    @GetMapping("/get")
    public Object get(@RequestParam String key) throws Exception {
        Element element = cache.get(key);
        if (element != null) {
            TypedCacheEntry entry = (TypedCacheEntry) element.getObjectValue();
            return entry.toObject();
        }
        return null;
    }

    @DeleteMapping("/delete")
    public String delete(@RequestParam String key) {
        cache.remove(key);
        producer.send(new CacheEvent(key, null, "DELETE"));
        return "DELETE success";
    }
}
