
package com.example.demo;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class CacheEventConsumer {

    private final Cache cache;

    public CacheEventConsumer(net.sf.ehcache.CacheManager cacheManager) {
        this.cache = cacheManager.getCache("demoCache");
    }

    @KafkaListener(topics = "cache-updates", groupId = "#{T(java.util.UUID).randomUUID().toString()}")
    public void handle(CacheEvent event) {
        if ("PUT".equalsIgnoreCase(event.getAction())) {
            cache.put(new Element(event.getKey(), event.getValue()));
        } else if ("DELETE".equalsIgnoreCase(event.getAction())) {
            cache.remove(event.getKey());
        }
    }
}
