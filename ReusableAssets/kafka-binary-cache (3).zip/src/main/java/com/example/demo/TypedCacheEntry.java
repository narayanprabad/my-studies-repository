
package com.example.demo;

import java.io.*;

public class TypedCacheEntry implements Serializable {
    private String className;
    private byte[] data;

    public TypedCacheEntry() {}

    public TypedCacheEntry(Object obj) throws IOException {
        this.className = obj.getClass().getName();
        this.data = serialize(obj);
    }

    public String getClassName() { return className; }
    public byte[] getData() { return data; }

    public Object toObject() throws IOException, ClassNotFoundException {
        return deserialize(data);
    }

    private byte[] serialize(Object obj) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(bos)) {
            out.writeObject(obj);
        }
        return bos.toByteArray();
    }

    private Object deserialize(byte[] data) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(data))) {
            return in.readObject();
        }
    }
}
