package com.demo.cluster.config;

import com.hazelcast.config.Config;
import com.hazelcast.config.JoinConfig;
import com.hazelcast.config.NetworkConfig;
import com.hazelcast.spring.cache.HazelcastCacheManager;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class HazelcastConfig {

    @Value("${hazelcast.cluster.members}")
    private List<String> clusterMembers;

    @Value("${hazelcast.network.port}")
    private int hazelcastPort;

    @Bean
    public HazelcastInstance hazelcastInstance() {
        Config config = new Config();
        config.setInstanceName("hazelcast-cluster-instance");

        NetworkConfig network = config.getNetworkConfig();
        network.setPort(hazelcastPort).setPortAutoIncrement(false);
        JoinConfig join = network.getJoin();
        join.getMulticastConfig().setEnabled(false);
        join.getTcpIpConfig().setEnabled(true);
        clusterMembers.forEach(member -> join.getTcpIpConfig().addMember(member));

        config.getMapConfig("sharedCache")
            .setTimeToLiveSeconds(300)
            .setBackupCount(1);

        return Hazelcast.newHazelcastInstance(config);
    }

    @Bean
    public CacheManager cacheManager(HazelcastInstance hazelcastInstance) {
        return new HazelcastCacheManager(hazelcastInstance);
    }
}
