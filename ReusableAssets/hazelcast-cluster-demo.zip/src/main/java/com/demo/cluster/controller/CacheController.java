package com.demo.cluster.controller;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cache")
public class CacheController {

    private final Cache cache;

    public CacheController(CacheManager cacheManager) {
        this.cache = cacheManager.getCache("sharedCache");
    }

    @PostMapping("/put")
    public String put(@RequestParam String key, @RequestParam String value) {
        cache.put(key, value);
        return "Value stored in cache.";
    }

    @GetMapping("/get")
    public String get(@RequestParam String key) {
        String value = cache.get(key, String.class);
        return value != null ? "Value: " + value : "Key not found.";
    }

    @DeleteMapping("/evict")
    public String evict(@RequestParam String key) {
        cache.evict(key);
        return "Key evicted.";
    }
}
