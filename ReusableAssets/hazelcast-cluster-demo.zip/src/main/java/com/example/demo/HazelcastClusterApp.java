
/*
Spring Boot Hazelcast clustering example using wildcard interface pattern.
This code runs 3 instances locally (on different ports) and auto-discovers
using interface wildcard (127.0.0.* for localhost).
*/

// Main Application
@SpringBootApplication
public class HazelcastClusterApp {
    public static void main(String[] args) {
        SpringApplication.run(HazelcastClusterApp.class, args);
    }
}

// Hazelcast Configuration
@Configuration
public class HazelcastConfig {

    @Value("${server.port}")
    private int port;

    @Value("${hazelcast.interface.pattern}")
    private String interfacePattern;

    @Bean
    public Config hazelcastConfig() {
        Config config = new Config();
        config.setInstanceName("hazelcast-instance-" + port);

        NetworkConfig networkConfig = config.getNetworkConfig();
        JoinConfig joinConfig = networkConfig.getJoin();

        joinConfig.getMulticastConfig().setEnabled(false);
        joinConfig.getTcpIpConfig()
                  .setEnabled(true)
                  .addMember(interfacePattern);

        networkConfig.getInterfaces()
                     .setEnabled(true)
                     .addInterface(interfacePattern);

        MapConfig mapConfig = new MapConfig("demoMap");
        mapConfig.setTimeToLiveSeconds(3600);
        config.addMapConfig(mapConfig);

        return config;
    }

    @Bean
    public HazelcastInstance hazelcastInstance(Config config) {
        return Hazelcast.newHazelcastInstance(config);
    }
}

// REST Controller to interact with cache
@RestController
public class CacheController {

    private final HazelcastInstance hazelcastInstance;

    public CacheController(HazelcastInstance hazelcastInstance) {
        this.hazelcastInstance = hazelcastInstance;
    }

    @GetMapping("/put")
    public String put(@RequestParam String key, @RequestParam String value) {
        hazelcastInstance.getMap("demoMap").put(key, value);
        return "Added [" + key + ":" + value + "] to cache.";
    }

    @GetMapping("/get")
    public Object get(@RequestParam String key) {
        return hazelcastInstance.getMap("demoMap").get(key);
    }

    @GetMapping("/members")
    public Object members() {
        return hazelcastInstance.getCluster().getMembers()
                .stream()
                .map(Member::getAddress)
                .toList();
    }
}
