
@RestController
public class CacheController {

    private final Cache<String, String> cache;
    private final KafkaTemplate<String, String> kafkaTemplate;

    public CacheController(javax.cache.CacheManager cacheManager, KafkaTemplate<String, String> kafkaTemplate) {
        this.cache = cacheManager.getCache("demoCache", String.class, String.class);
        this.kafkaTemplate = kafkaTemplate;
    }

    @PostMapping("/put")
    public String put(@RequestParam String key, @RequestParam String value) {
        cache.put(key, value);
        kafkaTemplate.send("cache-updates", key, value);
        return "Stored in local cache and published to Kafka";
    }

    @GetMapping("/get")
    public String get(@RequestParam String key) {
        return cache.get(key);
    }
}
