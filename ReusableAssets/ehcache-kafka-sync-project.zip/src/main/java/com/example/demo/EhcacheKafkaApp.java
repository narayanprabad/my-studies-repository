
@SpringBootApplication
public class EhcacheKafkaApp {
    public static void main(String[] args) {
        SpringApplication.run(EhcacheKafkaApp.class, args);
    }
}
