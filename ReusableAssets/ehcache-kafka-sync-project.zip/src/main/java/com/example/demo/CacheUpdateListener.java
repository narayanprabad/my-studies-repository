
@Component
public class CacheUpdateListener {

    private final Cache<String, String> cache;

    public CacheUpdateListener(javax.cache.CacheManager cacheManager) {
        this.cache = cacheManager.getCache("demoCache", String.class, String.class);
    }

    @KafkaListener(topics = "cache-updates", groupId = "cache-sync-group")
    public void listen(ConsumerRecord<String, String> record) {
        cache.put(record.key(), record.value());
        System.out.println("Updated local cache from Kafka: " + record.key() + " -> " + record.value());
    }
}
