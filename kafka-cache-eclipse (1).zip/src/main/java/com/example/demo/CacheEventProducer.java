
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class CacheEventProducer {

    @Autowired
    private KafkaTemplate<String, CacheEvent> kafkaTemplate;

    public void send(CacheEvent event) {
        kafkaTemplate.send("cache-updates", event.getKey(), event);
    }
}
