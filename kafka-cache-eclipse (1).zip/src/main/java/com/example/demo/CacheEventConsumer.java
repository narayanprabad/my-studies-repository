
package com.example.demo;

import javax.cache.Cache;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class CacheEventConsumer {

    private final Cache<String, String> cache;

    public CacheEventConsumer(javax.cache.CacheManager cacheManager) {
        this.cache = cacheManager.getCache("demoCache", String.class, String.class);
    }

    @KafkaListener(topics = "cache-updates", groupId = "#{T(java.util.UUID).randomUUID().toString()}")
    public void handle(CacheEvent event) {
        if ("PUT".equalsIgnoreCase(event.getAction())) {
            cache.put(event.getKey(), event.getValue());
        } else if ("DELETE".equalsIgnoreCase(event.getAction())) {
            cache.remove(event.getKey());
        }
    }
}
