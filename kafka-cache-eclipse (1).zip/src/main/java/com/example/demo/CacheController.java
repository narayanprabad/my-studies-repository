
package com.example.demo;

import javax.cache.Cache;
import org.springframework.web.bind.annotation.*;

@RestController
public class CacheController {

    private final Cache<String, String> cache;
    private final CacheEventProducer producer;

    public CacheController(javax.cache.CacheManager cacheManager, CacheEventProducer producer) {
        this.cache = cacheManager.getCache("demoCache", String.class, String.class);
        this.producer = producer;
    }

    @PostMapping("/put")
    public String put(@RequestParam String key, @RequestParam String value) {
        cache.put(key, value);
        producer.send(new CacheEvent(key, value, "PUT"));
        return "PUT success";
    }

    @DeleteMapping("/delete")
    public String delete(@RequestParam String key) {
        cache.remove(key);
        producer.send(new CacheEvent(key, null, "DELETE"));
        return "DELETE success";
    }

    @GetMapping("/get")
    public String get(@RequestParam String key) {
        return cache.get(key);
    }
}
